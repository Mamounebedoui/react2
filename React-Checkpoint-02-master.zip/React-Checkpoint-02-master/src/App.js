
import './App.css';
import React from 'react';

import AgentsList from "./AgentsList"
import "./App.css"

function App() {
  return (
    
 <div className="App">
            <header className="App-header">
                <h1 className="profile">Valorant</h1><AgentsList/>
            </header>
            
    </div>
  );
}

export default App;
