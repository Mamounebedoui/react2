const agents = [
    {
        name: "Brimstone",
        role: "Controller",
        nationality: "United States",
        ultimate: "Sorbital Strike",
        imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9amfpfDENBh49LVsWG-ph2PXz9us__J-XHg&s"
    },
    {
        name: "Sage",
        role: "Sentinel",
        nationality: "China",
        ultimate: "Resurrection",
        imageUrl: "https://prompthero.com/rails/active_storage/representations/proxy/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaWxrTnpKaU56RmtOUzFrTURsaExUUTVNbVV0T1RabE5pMHdPV05tWkRCbE16UmpNbVVHT2daRlZBPT0iLCJleHAiOm51bGwsInB1ciI6ImJsb2JfaWQifX0=--78a910bd59192c6b0762dd5ac522590109e979a8/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaDdDRG9MWm05eWJXRjBPZ2wzWldKd09oUnlaWE5wZW1WZmRHOWZiR2x0YVhSYkIya0NBQWhwQWdBSU9ncHpZWFpsY25zSk9oTnpkV0p6WVcxd2JHVmZiVzlrWlVraUIyOXVCam9HUlZRNkNuTjBjbWx3VkRvT2FXNTBaWEpzWVdObFZEb01jWFZoYkdsMGVXbGYiLCJleHAiOm51bGwsInB1ciI6InZhcmlhdGlvbiJ9fQ==--beed8ed72637ca3712935f65de3d18ae25f2cc85/102160.jpeg"
    },
    {
        name: "Sova",
        role: "Initiator",
        nationality: "Russia",
        ultimate: "Hunter's Fury",
        imageUrl: "https://www.boostingfactory.com/application/files/4816/7457/4579/sova-valorant-owl-drone-wallpaper.jpg"
    },
    {
        name: "Reyna",
        role: "Duelist",
        nationality: "Mexico",
        ultimate: "Empress",
        imageUrl: "https://cdnb.artstation.com/p/assets/images/images/040/696/069/large/saifuddin-dayana-reyna-valorant-saifuddindayana2021.jpg?1629641072"
    }]
    

export default agents;